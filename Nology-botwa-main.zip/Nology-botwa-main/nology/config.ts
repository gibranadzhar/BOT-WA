export default {
  ownerNumber: ["6283827963304"],
  ownerName: "Brannz",
  botName: "NologyBot",
  language: "id",

  mess: {
    owner: "Fitur ini hanya untuk owner bot!",
    wait: "⏳ Mohon tunggu sebentar...",
    error: "❌ Terjadi kesalahan!",
    done: "✅ Selesai!",
  }
};

/*

~> Script base bot whatsapp TypeScript ( TS )
~> Fauzialifatah ( pembuatan base )

~> Saluran: https://whatsapp.com/channel/0029VawsCnQ9mrGkOuburC1z

*/