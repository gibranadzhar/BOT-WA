# 🤖 NologyBot - WhatsApp Bot (Simple TypeScript)

Bot WhatsApp ringan dan mudah digunakan, cocok untuk pemula yang ingin belajar membuat bot sendiri.

---

## ✨ Fitur Utama

- ✅ Support tombol WhatsApp (tergantung versi `Baileys`)
- 🧠 Pakai TypeScript & JavaScript  
  ![TS](https://img.shields.io/badge/TypeScript-blue?logo=typescript) 
  ![JS](https://img.shields.io/badge/JavaScript-yellow?logo=javascript)
- 💡 Sangat simpel dan mudah dipahami
- 🔒 Tidak 100% terenkripsi
- ⚙️ Fokus untuk plugin WhatsApp
- 🔁 Login hanya lewat QR Code

---

## ⚠️ Catatan

- Tidak ada **backdoor**
- **Tidak untuk dijual**
- Bebas tambahkan fitur sendiri

> Script ini dibuat agar kamu bisa belajar bikin bot dari dasar.

---

## 👤 Pembuat

**Fauzialifatah** adalah pembuatan script bot whatsapp ini yang menggunakan **typescript** dan **javascript** ini script ini mudah bangat untuk di otak atik agar kalian paham dalam pebuatan script bot whatsapp jangan lupa untuk support selalu owner script nya

WhatsApp: [+6282132710183](https://wa.me/6282132710183)  
Saluran WhatsApp: [Followme](https://www.whatsapp.com/channel/0029VawsCnQ9mrGkOuburC1z?utm_medium=social&utm_source=heylink.me)  
Instagram: [@fauzialifatah_](https://instagram.com/fauzialifatah_)  
YouTube: [Fauzialifatah](https://www.youtube.com/@Fauzialifatah)

---

Selamat belajar dan selamat ngoprek bot kamu! 🚀
